//the rider's minimum height specified is 42 inches
var minHeight = 42;
// the rider's minimum age is 10 years
var minAge = 10;    
