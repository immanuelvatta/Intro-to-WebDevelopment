export function main() {
    function greeting(){
        return "Hello World";
    }
    var word = greeting();
    //added word inside the console.log() to print out the greeting "Hello World"
    console.log(word);
}