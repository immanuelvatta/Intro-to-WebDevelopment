// YOUR COMMENT HERE - what would this variable do?
// you initialize the like Count to 0
var likeCount = 0;
// YOUR COMMENT HERE - what would be the function of this code block?
//you create a function that would increase Likes
function increaseLikes() {
    // YOUR COMMENT HERE - what is this sort operation for?
    // this sort of operation makes sure that each like increments the like count by 1
    likeCount = likeCount + 1;
}